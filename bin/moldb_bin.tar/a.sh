#!/bin/bash

echo "
A
V
E
C
E
S
A
R"
